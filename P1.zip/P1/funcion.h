#ifndef FUNCION_H
#define FUNCION_H

#include "includes.h"
#include "list.h"

//Funciones de control
int trocear(char *entrada, char* salida[]);
int procesadoC(char* Arg[], int numA, tList* L);

#endif